---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 石英玻璃
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# 石英玻璃

<BlockImage id="quartz_glass" scale="8" />

几乎完全通透的玻璃，由<ItemLink id="certus_quartz_dust" />制成。用于制造大多数AE2机器和物品。

其变种聚能石英玻璃会发光。

## 配方

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
