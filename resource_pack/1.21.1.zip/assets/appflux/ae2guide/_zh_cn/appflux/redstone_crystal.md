---
navigation:
  parent: appflux/appflux-index.md
  title: 红石水晶
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# 红石水晶

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*“抛瓦！”*

红石是能量存储的好用媒介，但其结构过于松散，很难放到元件里去。

而将红石块和福鲁伊克斯水晶与荧石混合，就可结晶出红石水晶：它能在极小的体积中存下大量能量。
