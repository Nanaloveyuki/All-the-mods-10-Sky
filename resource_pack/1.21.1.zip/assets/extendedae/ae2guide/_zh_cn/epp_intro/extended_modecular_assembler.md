---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展分子装配室
    icon: extendedae:ex_molecular_assembler
categories:
- extended devices
item_ids:
- extendedae:ex_molecular_assembler
---

# 扩展分子装配室

<Row gap="20">
<BlockImage id="extendedae:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

扩展分子装配室是高级版本的<ItemLink id="ae2:molecular_assembler" />。

它能同时运行8个合成作业（当然ME网络中首先要有<ItemLink id="ae2:crafting_accelerator" />），作业的速度也是普通的装配室的2倍。

不过，它只接受<ItemLink id="ae2:pattern_provider" />发来的合成请求，而不能直接往其中放入样板。

