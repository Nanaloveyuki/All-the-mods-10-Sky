---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 熵变机械臂
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# 熵变机械臂

<ItemImage id="entropy_manipulator" scale="4" />

手持熵变机械臂右击和Shift右击可分别加热或冷却事物。它的功能不算多，只能蒸发或冻结水，将熔岩固化为黑曜石，将原木烧炼为木炭，将圆石烧炼为石头。

如果无法对方块做出特殊操作，则其与打火石表现相同。

可在<ItemLink id="charger" />中为其充能。

## 配方

<RecipeFor id="entropy_manipulator" />
